// Liste des domaines suspects par défaut
const defaultSuspiciousDomains = [
  'casino',
  'bet',
  'porn',
  'xxx',
  'adult',
  'click',
  'redirect',
  'popup'
];

// Fonction pour vérifier si une URL est suspecte
function isSuspiciousUrl(url) {
  const lowerUrl = url.toLowerCase();
  
  // Vérifier d'abord les domaines bloqués personnalisés
  return new Promise((resolve) => {
    chrome.storage.local.get(['blockedDomains'], function(result) {
      const blockedDomains = result.blockedDomains || [];
      const isBlocked = blockedDomains.some(domain => lowerUrl.includes(domain));
      
      if (isBlocked) {
        resolve(true);
      } else {
        // Vérifier ensuite les domaines suspects par défaut
        const isSuspicious = defaultSuspiciousDomains.some(domain => lowerUrl.includes(domain));
        resolve(isSuspicious);
      }
    });
  });
}

// Écouter les événements de navigation
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  // Vérifier si la navigation est initiée par l'utilisateur
  if (details.frameId === 0 && details.parentFrameId === -1) {
    // Si l'URL est suspecte, on annule la navigation
    const suspicious = await isSuspiciousUrl(details.url);
    if (suspicious) {
      chrome.tabs.update(details.tabId, { url: details.url });
      return { cancel: true };
    }
  }
}, { url: [{ schemes: ['http', 'https'] }] }); 